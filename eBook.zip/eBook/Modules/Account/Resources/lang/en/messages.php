<?php

return [
    'profile_updated' => 'Your profile has been updated.',
    'ebook_removed_from_favorite' => 'The ebook has been removed from your favorite.',
];
