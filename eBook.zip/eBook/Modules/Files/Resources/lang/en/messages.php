<?php

return [
    'image_has_been_added' => 'Image has been added.',
    'file_has_been_added' => 'File has been added.',
];
