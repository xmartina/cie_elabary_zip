<?php

return [
    'name' => 'Name',
    'slug' => 'Slug',
    'is_searchable' => 'Searchable',
    'is_active' => 'Status',
];
