<?php

return [
    'ebook' => 'Reported eBook',
    'ebooks' => 'Reported eBooks',
    'table' => [
        'title' => 'Title',
        'user' => 'User',
        'user' => 'Reported User',
        'reason' => 'Reason',
        'edit_ebook' => 'Edit eBook',
    ],
    
];
