<?php

return [
    'ebooks' => 'eBooks',
    'reportedebooks' => 'Reported eBooks',
];
