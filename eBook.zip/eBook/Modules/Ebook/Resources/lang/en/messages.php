<?php

return [
    'submitted_ebook_report' => 'Thank you for submitting a report.',
    'please_enter_valid_password' => 'Please Enter Valid Password',
    'please_enter_password_to_view_this_ebook' => 'Please enter password to view this ebook',
    'ebook_removed' => 'The ebook has been removed',
    'ebook_removed_error' => 'Some things might be wrong. Please try again later!',
];
