<?php

return [
    'index' => 'Index Authors',
    'create' => 'Create Authors',
    'edit' => 'Edit Authors',
    'destroy' => 'Delete Authors',
];
