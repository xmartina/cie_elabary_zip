<?php

return [
    'image' => 'Image',
    'name' => 'Name',
    'slug' => 'Slug',
    'description' => 'Description',
    'is_active' => 'Status',
    'is_verified' => 'Verified',
];
