<?php

return [
    'authors' => 'Authors',
];
