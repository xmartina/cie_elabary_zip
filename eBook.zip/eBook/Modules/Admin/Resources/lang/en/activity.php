<?php

return [
    'activity' => 'Activity',
    'activitylogs' => 'Activity Logs',
    'table'=>[
        'id'=>'ID',
        'user'=>'User Name',
        'activity'=>'Activity',
        'log_time'=>'Log Time',
        
    ],
];
