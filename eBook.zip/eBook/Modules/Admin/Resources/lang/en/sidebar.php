<?php

return [
    'menu' => 'Menu',
    'activity' => 'Activity',
    'activitylogs' => 'Activity Logs',
   
];
