<?php

return [
    'activity' => [
        'index' => 'Index activity',
    ],
   
];
