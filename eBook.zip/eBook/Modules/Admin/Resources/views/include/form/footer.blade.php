<button type="submit" class="btn btn-primary" data-loading>
{{ clean(trans('admin::admin.buttons.save')) }}
</button>

