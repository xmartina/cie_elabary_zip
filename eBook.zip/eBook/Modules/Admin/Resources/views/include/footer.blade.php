<div class="copyright ml-auto">
Copyright &copy; {{ date('Y')}} <a href="#" target="_blank">{{setting('site_name')}}</a>
</div>