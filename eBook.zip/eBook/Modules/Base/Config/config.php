<?php

return [
    'base_modules' => [
        'base',
        'admin',
        'dashboard',
        'meta',
        'user',
        'setting',
        'page',
        'ebook',
        'translation',
    ],
];
