<?php

return [
    'service_unavailable' => 'Service Unavailable',
    'maintenance_message' => 'Sorry, we are doing some maintenance. Please check back soon.',
    'mail_is_not_configured' => 'Mail is not configured properly.',
    'permission_denied' => 'Permission Denied (required permission: ":permission").',
    'the_given_data_was_invalid' => 'The given data was invalid.',
    'in_maintenance' => 'Sorry, we are doing some maintenance.',
];
