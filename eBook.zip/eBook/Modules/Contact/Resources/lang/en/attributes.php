<?php

return [
    'first_name' => 'First Name',
    'last_name' => 'Last Name',
    'email' => 'Email',
    'subject' => 'Subject',
    'message' => 'Message',
    'captcha' => 'Captcha',
];
