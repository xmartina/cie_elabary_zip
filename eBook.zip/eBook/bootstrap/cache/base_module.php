<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Base\\Providers\\BaseServiceProvider',
    1 => 'Modules\\Base\\Providers\\ModuleServiceProvider',
    2 => 'Modules\\Base\\Providers\\ThemeServiceProvider',
    3 => 'Modules\\Base\\Providers\\AssetServiceProvider',
    4 => 'Modules\\Base\\Providers\\EventServiceProvider',
    5 => 'Modules\\Base\\Providers\\MySQLScoutServiceProvider',
    6 => 'Modules\\Base\\Providers\\EloquentMacroServiceProvider',
    7 => 'Maatwebsite\\Sidebar\\SidebarServiceProvider',
    8 => 'Modules\\Base\\Providers\\SidebarServiceProvider',
    9 => 'Modules\\Base\\Providers\\SearchEngineServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Base\\Providers\\BaseServiceProvider',
    1 => 'Modules\\Base\\Providers\\ModuleServiceProvider',
    2 => 'Modules\\Base\\Providers\\ThemeServiceProvider',
    3 => 'Modules\\Base\\Providers\\AssetServiceProvider',
    4 => 'Modules\\Base\\Providers\\EventServiceProvider',
    5 => 'Modules\\Base\\Providers\\MySQLScoutServiceProvider',
    6 => 'Modules\\Base\\Providers\\EloquentMacroServiceProvider',
    7 => 'Maatwebsite\\Sidebar\\SidebarServiceProvider',
    8 => 'Modules\\Base\\Providers\\SidebarServiceProvider',
    9 => 'Modules\\Base\\Providers\\SearchEngineServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);