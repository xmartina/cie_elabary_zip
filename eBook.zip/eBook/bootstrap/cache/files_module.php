<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Files\\Providers\\FilesServiceProvider',
    1 => 'Modules\\Files\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Files\\Providers\\FilesServiceProvider',
    1 => 'Modules\\Files\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);