<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Translation\\Providers\\TranslationServiceProvider',
    1 => 'Modules\\Translation\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Translation\\Providers\\TranslationServiceProvider',
    1 => 'Modules\\Translation\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);