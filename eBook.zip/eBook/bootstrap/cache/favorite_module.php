<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Favorite\\Providers\\FavoriteServiceProvider',
    1 => 'Modules\\Favorite\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Favorite\\Providers\\FavoriteServiceProvider',
    1 => 'Modules\\Favorite\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);