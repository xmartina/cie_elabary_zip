<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Page\\Providers\\PageServiceProvider',
    1 => 'Modules\\Page\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Page\\Providers\\PageServiceProvider',
    1 => 'Modules\\Page\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);