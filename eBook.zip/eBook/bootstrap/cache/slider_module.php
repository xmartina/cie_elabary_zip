<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Slider\\Providers\\SliderServiceProvider',
    1 => 'Modules\\Slider\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Slider\\Providers\\SliderServiceProvider',
    1 => 'Modules\\Slider\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);